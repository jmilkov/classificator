# Classificator

## О проекте

Classificator — веб-приложение для управления приборами: метрики, измерения, HW-ревизии, подключённые сенсоры, места установок.

## Стек технологий

- **Runtime:** Node.js 20
- **Фреймворк:** Next.js 16 (App Router)
- **Язык:** JavaScript (ES-модули, `"type": "module"`)
- **UI:** React 19, Recharts (графики), PrismJS + react-simple-code-editor (редактор конфигураций)
- **Обработка изображений:** Sharp
- **Взаимодействие:** Axios (HTTP), MQTT (сообщения)
- **Утилиты:** date-fns, dotenv
- **Деплой:** Docker, Docker Compose, PM2

## Быстрый старт

### Предварительные требования

- Node.js 20+ и npm
- (опционально) Docker и Docker Compose

### Установка и запуск

```bash
# 1. Клонировать репозиторий
git clone <url-репозитория> classificator
cd classificator

# 2. Установить зависимости
npm install

# 3. Создать файл .env и заполнить переменные
# (шаблон .env.example не поставляется — создайте вручную)

# 4. Запустить dev-сервер
npm run dev
```

Приложение доступно на `http://localhost:3000`.

### Переменные окружения

| Переменная | Значение по умолчанию | Описание |
|---|---|---|
| `PORT` | `3000` | Порт HTTP-сервера |
| `CALL_MEDIA_TYPE_ID` | `5` | ID типа медиа звонка |
| `DEFAULT_PAGE_SIZE` | `20` | Размер страницы по умолчанию |
| `MAX_PAGE_SIZE` | `100` | Максимальный размер страницы |
| `ANCHOR_STEP` | `10` | Шаг якорей пагинации |
| `ANCHOR_TTL_SECONDS` | `1800` | Время жизни якорей в кэше (сек) |
| `DEFAULT_MASTER` | `1` | Режим «мастер» по умолчанию |
| `DEFAULT_AREA` | — | Зона по умолчанию |
| `DEFAULT_AREAS` | — | Список зон через запятую |

Все переменные опциональны — при отсутствии используются значения из `src/config/index.js`.

### Docker

```bash
docker compose up --build
```

Приложение доступно на `http://localhost:3082`.

## Архитектура и структура папок

Клиент-серверное приложение на Next.js 16 (App Router). Бэкенд — REST API через Route Handlers в `src/app/api/v1`. Фронтенд — React-компоненты в `src/components`, страницы в `src/app`.

```
.
├── .agents/                    # Конфигурация агентов Kilo
├── public/
│   ├── config/                 # JSON-конфигурации (сенсоры, метрики и т.д.)
│   └── uploads/                # Загруженные пользователем файлы
├── scripts/
│   └── increment-version.sh    # Автоинкремент версии при сборке
├── src/
│   ├── app/
│   │   ├── api/v1/             # REST API (Next.js Route Handlers)
│   │   │   ├── auth/           # Аутентификация: login, logout, me
│   │   │   ├── config/         # Чтение/обновление конфигурации приложения
│   │   │   ├── measurements/   # Измерения (list, save, delete)
│   │   │   ├── metrics/        # Метрики (list, save, delete)
│   │   │   ├── metric-categories/ # Категории метрик (list, save, delete)
│   │   │   ├── connected-sensors/ # Подключаемые сенсоры (list, save, delete, upload)
│   │   │   ├── hw-revision/    # HW-ревизии (list, save, delete)
│   │   │   └── json-parser/    # Парсинг и анализ JSON
│   │   ├── page.js             # Главная страница
│   │   ├── config/page.js      # Управление JSON-конфигурациями
│   │   ├── measurements/page.js
│   │   ├── metrics/page.js
│   │   ├── metric-categories/page.js
│   │   ├── connected-sensors/page.js
│   │   ├── hw-revision/page.js
│   │   ├── sensors/page.js     # Приборы (в разработке)
│   │   ├── locations/page.js
│   │   ├── layout.js           # Корневой layout
│   │   └── globals.css         # Глобальные стили
│   ├── components/             # Переиспользуемые React-компоненты
│   │   ├── DashboardLayout.js  # Обвязка дашборда: аутентификация, сайдбар
│   │   ├── SlideMenuBar.js     # Боковое меню навигации
│   │   ├── LoginScreen.js      # Экран входа
│   │   ├── ConfigManagement.js # Редактор JSON-конфигураций
│   │   ├── MeasurementsManagement.js
│   │   ├── MetricsManagement.js
│   │   ├── MetricCategoriesManagement.js
│   │   └── SensorModelsManagement.js
│   ├── config/                 # Серверная конфигурация (env → объект config)
│   ├── services/               # Бизнес-логика и инфраструктурные сервисы
│   │   └── anchorStore.js      # Кэш якорей пагинации
│   └── utils/                  # Утилиты
│       ├── api.js              # HTTP-клиент для внутреннего API
│       └── auth.js             # Сессии, проверка учётных данных, ошибки API
├── Dockerfile                  # Многостадийная сборка (deps → builder → runner)
├── docker-compose.yml          # Локальный запуск, порт 3082:3000
├── next.config.mjs             # Конфигурация Next.js (standalone, rewrites)
├── jsconfig.json               # Путь-алиас @/* → src/*
└── package.json
```

Роль ключевых папок:

- `src/app` — точка входа Next.js: все маршруты (страницы и API) определяются по структуре папок.
- `src/app/api/v1` — серверный REST API версии v1 на Route Handlers.
- `src/components` — клиентские React-компоненты.
- `src/config` — чтение `.env` и преобразование в типизированный объект конфигурации.
- `src/services` — сервисы с бизнес-логикой.
- `src/utils` — вспомогательные модули (HTTP-клиент, аутентификация).
- `public/config` — JSON-файлы конфигураций сенсоров, метрик и измерений.
- `scripts` — вспомогательные скрипты сборки (версионирование).

## Тестирование

Проект ведётся по подходу **Test-Driven Development (TDD)**: сначала пишется падающий тест, затем минимальная реализация, затем рефакторинг.

> Тестовая инфраструктура ещё настраивается. Запуск тестов после подключения:

```bash
npm test
```

Команда станет доступной после подключения тестового фреймворка.